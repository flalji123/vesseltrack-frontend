import React from 'react'
import { Routes, Route, Link } from 'react-router-dom'

export default function App() {
  return (
    <div style={{ display: 'flex' }}>
      <nav style={{ width: 200, background: '#111', color: '#fff', padding: 20 }}>
        <ul style={{ listStyle: 'none', padding: 0 }}>
          <li><Link to="/dashboard" style={{ color: '#fff' }}>Dashboard</Link></li>
          <li><Link to="/search" style={{ color: '#fff' }}>Search</Link></li>
          <li><Link to="/cargo" style={{ color: '#fff' }}>Cargo</Link></li>
        </ul>
      </nav>
      <main style={{ padding: 20 }}>
        <Routes>
          <Route path="/" element={<h1>Welcome to VesselTrack</h1>} />
          <Route path="/dashboard" element={<h2>Dashboard Page</h2>} />
          <Route path="/search" element={<h2>Search Page</h2>} />
          <Route path="/cargo" element={<h2>Cargo Page</h2>} />
        </Routes>
      </main>
    </div>
  )
}
